#!/bin/sh

opcion=$(printf "Apagar\nReiniciar\nCerrar sesión" | fuzzel --dmenu -p "Sistema: ")

ejecutar_energia() {
    accion="$1"

    if command -v loginctl >/dev/null 2>&1 && loginctl "$accion" >/dev/null 2>&1; then
        exit 0
    fi

    if "$accion" >/dev/null 2>&1; then
        exit 0
    fi

    if command -v sudo >/dev/null 2>&1 && sudo -n "$accion" >/dev/null 2>&1; then
        exit 0
    fi

    if command -v doas >/dev/null 2>&1 && doas -n "$accion" >/dev/null 2>&1; then
        exit 0
    fi

    if command -v notify-send >/dev/null 2>&1; then
        notify-send "Menú de Energía" "Sin permisos para '$accion'. Configura sudo/doas NOPASSWD o elogind."
    fi
}

case "$opcion" in
    "Apagar")
        ejecutar_energia poweroff
        ;;
    "Reiniciar")
        ejecutar_energia reboot
        ;;
    "Cerrar sesión")
        labwc --exit
        ;;
esac
